package com.tangkaptelorayam.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class tangkapTelorAyam extends Game {
	public SpriteBatch batch;
	public BitmapFont Font;

	public void create() {
		batch = new SpriteBatch();
		Font = new BitmapFont();
		this.setScreen(new mainMenuScreen(this));
	}

	public void render() {
		super.render();
	}

}


