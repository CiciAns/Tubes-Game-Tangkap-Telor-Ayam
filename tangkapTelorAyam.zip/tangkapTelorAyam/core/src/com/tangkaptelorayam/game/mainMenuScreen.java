package com.tangkaptelorayam.game;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.ScreenUtils;

public class mainMenuScreen implements Screen {
    final tangkapTelorAyam game;
    OrthographicCamera camera;

    public mainMenuScreen (final tangkapTelorAyam game){
        this.game = game;
        camera = new OrthographicCamera();
        camera.setToOrtho(false,800,480);
    }

    @Override
    public void render(float delta){
        ScreenUtils.clear(0,0,0.2f,1);
        Texture background;

        background = new Texture(Gdx.files.internal("ladang.png"));
                camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        game.batch.begin();
        game.batch.draw(background,0,0,800,480);
        game.Font.draw(game.batch,"Selamat Datang di Game Tangkap Telor Ayam",250,300);
        game.Font.draw(game.batch,"Silahkan klik untuk memulai permainan ini",230,270);
        game.batch.end();

        if (Gdx.input.isTouched())game.setScreen(new gameScreen(game));
        dispose();
    }

    @Override
    public void show() {

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}