package com.tangkaptelorayam.game;

import com.badlogic.gdx.Screen;
import java.util.Iterator;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.TimeUtils;

public class gameScreen implements Screen {
    final tangkapTelorAyam game;
    private Texture keranjang;
    private Texture telur;
    private Texture background;
    private OrthographicCamera camera;
    private Rectangle gambarKeranjang;
    private Array<Rectangle> telorJatuh;
    private long waktuJatuh;
    private int telurJatuh;

    public gameScreen(final tangkapTelorAyam game) {
        this.game = game;
        telur = new Texture(Gdx.files.internal("telur.png"));
        keranjang = new Texture(Gdx.files.internal("keranjang.png"));
        background = new Texture(Gdx.files.internal("ladang.png"));
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 800, 480);
        gambarKeranjang = new Rectangle();
        gambarKeranjang.x = 800 / 2 - 64 / 2;
        gambarKeranjang.y = 20;
        gambarKeranjang.width = 70;
        gambarKeranjang.height = 70;
        telorJatuh = new Array<Rectangle>();
        telurjatuh2();
    }
private void telurjatuh2(){
        Rectangle telurjatuh2 = new Rectangle();
        telurjatuh2.x = MathUtils.random(0,800-64);
        telurjatuh2.y = 480;
        telurjatuh2.width = 10;
        telurjatuh2.height = 10;
        telorJatuh.add(telurjatuh2);
        waktuJatuh = TimeUtils.nanoTime();
}

    @Override
    public void show() {

    }

    @Override
    public void render(float delta){
        ScreenUtils.clear(0,0,0.2f,1);
        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        game.batch.begin();
        game.batch.draw(background,0,0,800,480);
        game.Font.draw(game.batch,"Telur yang masuk dalam keranjang : " + telurJatuh, 300, 375);
        game.batch.draw(keranjang, gambarKeranjang.x, gambarKeranjang.y, gambarKeranjang.width, gambarKeranjang.height );
        for (Rectangle telurjatuh2 : telorJatuh){
            game.batch.draw(telur,telurjatuh2.x,telurjatuh2.y);
        }
        game.batch.end();

        if (Gdx.input.isTouched()){
            Vector3 touchpose = new Vector3();
            touchpose.set(Gdx.input.getX(),Gdx.input.getY(),0);
            camera.unproject(touchpose);
            gambarKeranjang.x = touchpose.x - 64/2;
        }

        if (Gdx.input.isKeyPressed(Keys.LEFT)) gambarKeranjang.x -= 200*Gdx.graphics.getDeltaTime();
        if (Gdx.input.isKeyPressed(Keys.RIGHT)) gambarKeranjang.x += 200*Gdx.graphics.getDeltaTime();
        if (Gdx.input.isKeyPressed(Keys.UP)) gambarKeranjang.y += 200*Gdx.graphics.getDeltaTime();
        if (Gdx.input.isKeyPressed(Keys.DOWN)) gambarKeranjang.y -= 200*Gdx.graphics.getDeltaTime();
        if (gambarKeranjang.x < 0) gambarKeranjang.x = 0;
        if (gambarKeranjang.x > 800-64) gambarKeranjang.x = 800-64;
        if (gambarKeranjang.y < 0) gambarKeranjang.y = 0;
        if (gambarKeranjang.y > 480) gambarKeranjang.y = 480;

        if (TimeUtils.nanoTime()- waktuJatuh > 1000000000) telurjatuh2();
        Iterator<Rectangle> iter = telorJatuh.iterator();
        while (iter.hasNext()){
            Rectangle telurjatuh2 = iter.next();
            telurjatuh2.y -= 200*Gdx.graphics.getDeltaTime();
            if (telurjatuh2.y + 64<0) iter.remove();
            if (telurjatuh2.overlaps(gambarKeranjang)){
                telurJatuh++;
                iter.remove();
            }
        }

}

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        keranjang.dispose();
        telur.dispose();
        background.dispose();

    }

}

